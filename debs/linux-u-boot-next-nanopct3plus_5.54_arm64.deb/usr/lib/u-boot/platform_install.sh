DIR=/usr/lib/linux-u-boot-next-nanopct3plus_5.54_arm64
write_uboot_platform () 
{ 
    dd if=$1/boot.img of=$2 seek=1 status=noxfer > /dev/null 2>&1
}

