DIR=/usr/lib/linux-u-boot-helios4_5.40_armhf
write_uboot_platform () 
{ 
    dd if=$1/u-boot.mmc of=$2 bs=512 seek=1 status=noxfer > /dev/null 2>&1
}

