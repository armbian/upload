DIR=/usr/lib/linux-u-boot-odroidxu4_5.58_armhf
write_uboot_platform () 
{ 
    if [[ $2 == /dev/mmcblk* && -b ${2}boot0 ]]; then
        local device=${2}boot0;
        echo 0 > /sys/block/$(basename $device)/force_ro;
        local is_emmc=1;
        signed_bl1_position=0;
        bl2_position=30;
        uboot_position=62;
    else
        local device=${2};
        signed_bl1_position=1;
        bl2_position=31;
        uboot_position=63;
    fi;
    if [[ -f $1/u-boot.bin ]]; then
        if [[ $is_emmc == 1 ]]; then
            tzsw_position=718;
            env_position=1230;
        else
            tzsw_position=719;
            env_position=1231;
        fi;
        dd if=$1/bl1.bin.hardkernel of=$device seek=$signed_bl1_position conv=fsync > /dev/null 2>&1;
        dd if=$1/bl2.bin.hardkernel of=$device seek=$bl2_position conv=fsync > /dev/null 2>&1;
        dd if=$1/u-boot.bin of=$device bs=512 seek=$uboot_position conv=fsync > /dev/null 2>&1;
        dd if=$1/tzsw.bin.hardkernel of=$device seek=$tzsw_position conv=fsync > /dev/null 2>&1;
        dd if=/dev/zero of=$device seek=$env_position count=32 bs=512 conv=fsync > /dev/null 2>&1;
    else
        if [[ $is_emmc == 1 ]]; then
            tzsw_position=1502;
        else
            tzsw_position=1503;
        fi;
        env_position=2015;
        dd if=$1/bl1.bin.hardkernel of=$device seek=$signed_bl1_position conv=fsync > /dev/null 2>&1;
        dd if=$1/bl2.bin.hardkernel.720k_uboot of=$device seek=$bl2_position conv=fsync > /dev/null 2>&1;
        dd if=$1/u-boot-dtb.bin of=$device bs=512 seek=$uboot_position conv=fsync > /dev/null 2>&1;
        dd if=$1/tzsw.bin.hardkernel of=$device seek=$tzsw_position conv=fsync > /dev/null 2>&1;
        dd if=/dev/zero of=$device seek=$env_position bs=512 count=32 conv=fsync > /dev/null 2>&1;
    fi
}
setup_write_uboot_platform () 
{ 
    local tmp=$(cat /proc/cmdline);
    tmp="${tmp##*root=}";
    tmp="${tmp%% *}";
    [[ -n $tmp ]] && local part=$(findfs $tmp 2>/dev/null);
    [[ -n $part ]] && local dev=$(lsblk -n -o PKNAME $part 2>/dev/null);
    [[ -n $dev && $dev == mmcblk* ]] && DEVICE="/dev/${dev}"
}
