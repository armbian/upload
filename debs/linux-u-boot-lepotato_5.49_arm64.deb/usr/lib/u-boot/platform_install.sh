DIR=/usr/lib/linux-u-boot-lepotato_5.49_arm64
write_uboot_platform () 
{ 
    dd if=$1/u-boot.bin of=$2 bs=1 count=442 conv=fsync > /dev/null 2>&1;
    dd if=$1/u-boot.bin of=$2 bs=512 skip=1 seek=1 conv=fsync > /dev/null 2>&1
}

