DIR=/usr/lib/linux-u-boot-next-cubox-i_5.44_armhf
write_uboot_platform () 
{ 
    dd if=$1/SPL of=$2 bs=1K seek=1 status=noxfer > /dev/null 2>&1;
    dd if=$1/u-boot.img of=$2 bs=1K seek=69 status=noxfer > /dev/null 2>&1
}

