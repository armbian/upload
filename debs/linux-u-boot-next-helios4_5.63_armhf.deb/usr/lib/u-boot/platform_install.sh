DIR=/usr/lib/linux-u-boot-next-helios4_5.63_armhf
write_uboot_platform () 
{ 
    dd if=$1/u-boot.mmc of=$2 bs=512 seek=1 status=noxfer > /dev/null 2>&1
}
write_uboot_platform_mtd () 
{ 
    dd if=$1/u-boot.flash of=$2 status=noxfer > /dev/null 2>&1
}

