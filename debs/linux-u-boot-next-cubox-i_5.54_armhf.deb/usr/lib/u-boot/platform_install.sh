DIR=/usr/lib/linux-u-boot-next-cubox-i_5.54_armhf
write_uboot_platform () 
{ 
    dd if=$1/SPL of=$2 bs=512 seek=2 status=noxfer > /dev/null 2>&1;
    dd if=$1/u-boot.img of=$2 bs=1K seek=42 status=noxfer > /dev/null 2>&1
}

