DIR=/usr/lib/linux-u-boot-next-espressobin_5.54_arm64
write_uboot_platform () 
{ 
    /bin/true
}

