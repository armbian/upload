DIR=/usr/lib/linux-u-boot-next-odroidc2_5.54_arm64
write_uboot_platform () 
{ 
    dd if=$1/bl1.bin.hardkernel of=$2 bs=1 count=442 conv=fsync > /dev/null 2>&1;
    dd if=$1/bl1.bin.hardkernel of=$2 bs=512 skip=1 seek=1 conv=fsync > /dev/null 2>&1;
    dd if=$1/u-boot.bin of=$2 bs=512 seek=97 conv=fsync > /dev/null 2>&1
}

